from collections import deque
from utils.api import COLORS, DIRECTIONS

class LeftHand:
    def __init__(self, mouse):
        self.mouse = mouse
        self.w = mouse.maze_width
        self.h = mouse.maze_height
        self.orient = DIRECTIONS.EAST  # Start facing East
        self.current = (0, 0)
        self.walls = {}
        self.mapping = {
            DIRECTIONS.EAST: (0, 1),
            DIRECTIONS.SOUTH: (1, 0),
            DIRECTIONS.WEST: (0, -1),
            DIRECTIONS.NORTH: (-1, 0),
        }
        self.log("Starting at (0, 0)")

    def log(self, *args):
        """Logging function to output to console and file."""
        log_message = " ".join(map(str, args))
        print(log_message)
        
        # Save to a log file
        with open("lefthand_log.txt", "a") as log_file:
            log_file.write(log_message + "\n")

    def update_walls(self):
        """Update walls based on current sensor readings."""
        if self.current in self.walls:
            return
        
        lw, fw, rw = self.mouse.wall_left, self.mouse.wall_front, self.mouse.wall_right
        walls = set()

        if lw:
            walls.add(DIRECTIONS(self.orient - 1 if self.orient > 1 else 4))  # Left wall
        if fw:
            walls.add(self.orient)  # Front wall
        if rw:
            walls.add(DIRECTIONS(self.orient + 1 if self.orient < 4 else 1))  # Right wall

        self.walls[self.current] = list(walls)
        self.log(f"At {self.current}, detected walls: {walls}")

    def move(self):
        """Moves the mouse based on the Left-Hand Rule."""
        
        # If surrounded by walls on all four directions (north, east, south, west), go back to the starting point
        if DIRECTIONS.NORTH in self.walls.get(self.current, []) and \
           DIRECTIONS.EAST in self.walls.get(self.current, []) and \
           DIRECTIONS.SOUTH in self.walls.get(self.current, []) and \
           DIRECTIONS.WEST in self.walls.get(self.current, []):
            self.log("Surrounded on all sides, trying to reset")
            return False  # All directions blocked, stop
        
        # Check if the mouse is surrounded by 3 walls
        if len(self.walls.get(self.current, [])) == 3:
            self.spin_until_open_path()
        
        elif DIRECTIONS(self.orient - 1 if self.orient > 1 else 4) not in self.walls.get(self.current, []):
            self.turn_left()
            self.move_forward()
        elif self.orient not in self.walls.get(self.current, []):
            self.move_forward()
        elif DIRECTIONS(self.orient + 1 if self.orient < 4 else 1) not in self.walls.get(self.current, []):
            self.turn_right()
            self.move_forward()
        else:
            self.log("No possible moves, stopping!")
            return False  # All directions blocked, stop
        
        self.log(f"Moved to {self.current}")
        return True

    def spin_until_open_path(self):
        """Spin in place until an open path is found."""
        self.log(f"Surrounded by 3 walls at {self.current}, spinning until open path is found.")
        
        # Spin 4 times (360 degrees)
        for _ in range(4):
            self.turn_right()  # Turn right (90 degrees)
            self.update_walls()
            # Check if there is an open path in front of the mouse
            if self.orient not in self.walls.get(self.current, []):
                self.log(f"Found an open path at {self.current}, moving forward.")
                self.move_forward()
                return

        self.log("No open path found after spinning, stopping!")
        return False  # No open path found

    def turn_left(self):
        """Turn left and update the orientation."""
        self.orient = DIRECTIONS(self.orient - 1 if self.orient > 1 else 4)
        self.mouse.turn_left()

    def turn_right(self):
        """Turn right and update the orientation."""
        self.orient = DIRECTIONS(self.orient + 1 if self.orient < 4 else 1)
        self.mouse.turn_right()

    def move_forward(self):
        """Move forward in the current direction."""
        self.mouse.move_forward()
        dx, dy = self.mapping[self.orient]
        self.current = (self.current[0] + dx, self.current[1] + dy)

    def run(self, debug=False):
        """Run the Left-Hand Rule algorithm."""
        while True:
            self.update_walls()
            if not self.move():
                break  # Stop if no valid move
            if debug:
                self.mouse.set_color(*self.current, COLORS.DARK_YELLOW)
        return self.current
